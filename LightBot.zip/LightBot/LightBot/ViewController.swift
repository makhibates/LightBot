//
//  ViewController.swift
//  LightBot
//
//  Created by HGPMAC93 on 7/8/19.
//  Copyright © 2019 HGPMAC93. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
    }
    
}


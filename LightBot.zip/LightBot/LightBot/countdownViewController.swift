//
//  countdownViewController.swift
//  LightBot
//
//  Created by HGPMAC93 on 7/25/19.
//  Copyright © 2019 HGPMAC93. All rights reserved.
//

import UIKit

class countdownViewController: UIViewController {
    
    var seconds = 30
    var timer = Timer()
    
    @IBOutlet weak var label: UILabel!
    @IBOutlet weak var sliderOutlet: UISlider!
    @IBOutlet weak var startOutlet: UIButton!
    @IBOutlet weak var stopOutlet: UIButton!
    
    
    @IBAction func slider(_ sender: UISlider)
    {
       seconds = Int(sender.value)
        label.text = String(seconds) + " seconds"
    }

    @IBAction func start(_ sender: Any)
    {
        timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(counter), userInfo: nil, repeats: true)
        
        sliderOutlet.isHidden = true
        startOutlet.isHidden = true
    }
    
    @IBAction func stopFunction(_ sender: UIButton) {
        
        timer.invalidate()
        seconds = 30
        sliderOutlet.setValue(30, animated: true)
        label.text = "30 seconds"
        
        sliderOutlet.isHidden = false
        startOutlet.isHidden = false
    }

    @objc func counter()
    {
       seconds -= 1
        label.text = String(seconds) + " seconds"
        
        if (seconds == 0)
        {
           timer.invalidate()
            
            sliderOutlet.isHidden = false
            startOutlet.isHidden = false
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
